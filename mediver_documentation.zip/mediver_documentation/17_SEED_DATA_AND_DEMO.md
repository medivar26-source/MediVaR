# Seed Data and Demo Scenarios

## Demo institution

`Mediver Demo Hospital`

## Demo program

`Total Knee Arthroplasty - Residency Training`

## Cohort 2026A
- residents: 24
- progress: 68%
- average competency: 72%
- completion: 16/24
- at risk: 3
- next session: Today, 2:00 PM

## Cohort 2026B
- residents: 18
- progress: 42%
- average competency: 65%
- completion: 7/18
- at risk: 5
- next session: Tomorrow, 10:00 AM

## Resident example

Arun Kumar:
- competency 54%
- status At risk
- previous competency 62%
- completion 42%
- cases 5/12
- assessments 3/8

Skill examples:
- Bone cuts & alignment 48%
- Gap assessment 61%
- Trialling & stability 72%
- Implantation 55%

Weaknesses:
1. Tibial cut execution
2. Femoral alignment
3. Gap assessment

## Case example

`Varus OA - Right Knee`

- Difficulty: Intermediate
- Objective: Practice alignment + bone cuts
- Assessment criteria: mechanical alignment, tibial cut, femoral cut, gap balance

## Attempt example

```text
Tibial angle planned: 3°
Tibial angle executed: 6°
Difference: +3°
Result: FAILED
```

This is demo/test data, not a universal clinical rule.

## Test fixtures

Create deterministic fixtures for pass, fail, critical failure, incomplete, duplicate event, missing event, reconnect and no-data cases.
