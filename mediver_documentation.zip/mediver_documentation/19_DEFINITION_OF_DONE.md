# Definition of Done

A feature is not complete because the UI renders.

## Product
- Requirement documented
- User journey documented
- Acceptance criteria defined

## Frontend
- UI implemented
- loading/empty/error/unauthorized states
- validation
- accessibility basics

## Backend
- API
- authorization
- validation
- structured errors
- logging
- tests

## Database
- migration
- constraints
- indexes
- seed/update path where needed

## Assessment features
- deterministic
- explainable
- versioned
- raw evidence preserved
- clinical rules sourced/configured
- historical result not silently overwritten

## VR
- contract documented
- event schema validated
- retry/idempotency
- reconnect handling
- attempt lifecycle tested

## Reporting
- source and formula documented
- authorization enforced
- export tested

## Operations
- monitoring/logging
- backup implications considered
- failure modes documented

## Phase gate

A phase is complete only when implementation works, tests pass, documentation is updated, unresolved assumptions are written down, and no critical security/clinical issue is hidden.

## Production gate

Production/pilot additionally requires clinical validation, security review, recovery test, assessment golden tests, VR integration tests, and stakeholder acceptance.
