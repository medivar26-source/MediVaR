# Antigravity Build Plan

## Operating rule

Do not ask Antigravity to build the entire product in one giant prompt. Implement one phase at a time, run its gates, and stop.

## Phase 0 - Documentation lock

**Goal:** make `/docs` the implementation contract.

Tasks:
- read all docs
- identify contradictions
- do not silently resolve clinical contradictions
- create `IMPLEMENTATION_ASSUMPTIONS.md`
- create architecture/task plan

**Exit gate:** no coding until scope and assumptions are understood.

## Phase 1 - Repository foundation

**Goal:** working engineering skeleton.

Tasks:
- frontend skeleton
- backend skeleton
- DB connection layer
- env configuration
- health/readiness endpoints
- logging
- structured API errors
- test runner
- lint/typecheck
- local dev setup

**Gate:** fresh checkout runs the skeleton.

## Phase 2 - Database

**Goal:** implement the documented PostgreSQL model.

Tasks:
- migrations
- foreign keys
- constraints
- indexes
- deterministic seed data

**Gate:** clean DB migrates and seeds from scratch.

## Phase 3 - Authentication and RBAC

**Goal:** protect the platform.

Tasks:
- login
- sessions/tokens
- current-user endpoint
- role checks
- institution scope
- protected routes

**Gate:** cross-institution access is denied.

## Phase 4 - Instructor program management

**Goal:** build administrative core.

Tasks:
- dashboard shell
- curriculum
- cases
- procedures
- skills
- assessment settings
- content library

**Gate:** instructor can configure a complete program without direct DB access.

## Phase 5 - Cohorts and residents

**Goal:** connect configuration to learners.

Tasks:
- cohort CRUD
- resident management
- membership
- assignments
- resident profile

**Gate:** instructor can create cohort -> add residents -> assign case.

## Phase 6 - Sessions

**Goal:** establish training-event lifecycle.

Tasks:
- upcoming/live/completed
- session detail
- participants
- start/end
- state machine

**Gate:** instructor can schedule and operate a session.

## Phase 7 - Attempts and VR contracts

**Goal:** stable VR boundary.

Tasks:
- attempt creation
- event ingestion
- measurement ingestion
- idempotency
- sequence validation
- completion
- reconnect handling

**Gate:** simulated VR client can create an attempt and send events.

## Phase 8 - Assessment engine

**Goal:** deterministic, explainable assessment.

Tasks:
- criteria evaluator
- error detector
- skill aggregator
- overall-score pipeline
- auto-failure rules
- explanation payload
- recommendation generator

**Gate:** golden tests are deterministic.

**Blocker:** do not invent undefined clinical tolerances or competency formulas.

## Phase 9 - Instructor review

**Goal:** make assessment actionable.

Tasks:
- attempt review
- plan vs execution
- errors
- skills
- feedback
- notes
- recommendations

**Gate:** instructor can move from alert -> evidence -> action.

## Phase 10 - Real-time monitoring

**Goal:** live sessions without refresh.

Tasks:
- WebSocket
- participant status
- current step
- progress
- connection state

**Gate:** two clients observe the same session state reliably.

## Phase 11 - Reporting

**Goal:** resident, cohort, case and skill reports.

Tasks:
- reports
- exports/share
- documented metric definitions

**Gate:** every metric has source and derivation documentation.

## Phase 12 - Preoperative planning integration

**Goal:** represent FLAP/KLAT planning and transfer locked plan to VR.

Tasks:
- planning data model
- assessment page
- femoral planning
- tibial planning
- review/lock
- versioned plan
- VR payload

**Gate:** locked plan is referenced unambiguously by an attempt.

Clinical algorithms require approval before being authoritative.

## Phase 13 - Hardening

**Goal:** release readiness.

Tasks:
- audit logs
- permission tests
- backups/recovery
- performance
- accessibility
- security checks
- regression suite

**Gate:** all critical checks pass.

## Phase 14 - Pilot

**Goal:** validate with controlled users.

Tasks:
- pilot deployment
- approved content
- instructor workflow validation
- resident VR validation
- assessment validation
- report validation
- issue triage

**Gate:** clinical stakeholders approve pilot outcome.

## Build order

```text
0 Docs
1 Foundation
2 Database
3 Auth/RBAC
4 Program Management
5 Cohorts/Residents
6 Sessions
7 VR Contracts
8 Assessment
9 Review
10 Real-Time
11 Reports
12 Planning
13 Hardening
14 Pilot
```
