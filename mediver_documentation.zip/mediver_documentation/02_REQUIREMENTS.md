# Requirements

## Functional requirements

### Identity
- Users can authenticate.
- Users belong to an institution.
- Users have roles.
- Access is checked server-side.

### Programs
- Instructor can create and manage a program.
- Program status can be managed.
- Program contains curriculum, cases, skills and assessment configuration.

### Cohorts
- Instructor can create a cohort.
- Residents can be added to a cohort.
- Cohort progress and performance are visible.
- At-risk residents can be identified from defined rules.

### Cases
A case supports name, difficulty, description, learning objective, procedure, status, version, and assessment criteria.

### Skills
Current framework:
- Bone Cuts & Alignment: 30%
- Gap Assessment: 25%
- Trialling & Stability: 25%
- Implantation: 20%

The weights are product configuration, not a universal clinical rule.

### Assessment settings
Current example configuration:
- Passing score: 70%
- Critical error -> automatic failure: ON
- Incomplete procedure -> automatic failure: ON
- Guidance during assessment -> OFF

These are configurable values.

### Sessions
Instructor can create, schedule, assign residents, choose a case/mode, start/end a session, and observe live state.

### Attempts
An attempt records resident, session, case, attempt number, start/completion times, status, raw execution data, and assessment result.

### Feedback
Instructor can attach feedback to an attempt and notes to a resident.

### Reports
Minimum report families: resident, cohort, case, skill, export/share.

## Non-functional requirements

### Reliability
No completed assessment may disappear because a UI session ends.

### Security
Every protected resource must be authorized on the backend.

### Auditability
Changes to clinically relevant configuration and assessment results should be traceable.

### Performance
Use efficient queries and indexes first. Add dedicated analytics infrastructure only when justified by measured need.

### Maintainability
Clinical rules should live in versioned/configurable backend structures rather than frontend code.

### Extensibility
Additional procedures/cases/skills should be addable without redesigning the entire schema.
