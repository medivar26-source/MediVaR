# Deployment and Operations

## Environments

Use at least:
- local
- development
- staging
- production/pilot

## Database migrations

- migration files are source controlled
- migrations run in deployment
- destructive migrations require explicit approval
- backups precede high-risk changes
- restoration is tested

## Configuration

Separate application config, DB config, secrets, clinical-content configuration, and environment-specific URLs.

## Observability

Track API errors, assessment failures, event ingestion failures, WebSocket disconnects, slow queries, job failures, and authentication failures.

## Backups

Back up PostgreSQL and important object-storage artifacts. Test restore procedures regularly.

## Health checks

```text
GET /health
GET /ready
```

These endpoints should not leak sensitive internals.

## Rollout

```text
Development
-> Staging
-> Internal validation
-> Clinical/pilot validation
-> Small cohort
-> Broader rollout
```

## Rollback

Each release should have a known version, migration plan, rollback/forward-fix strategy, and owner. Never leave production data in an ambiguous schema state.
