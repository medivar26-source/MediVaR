# TKA Planning and Clinical Data

## Source basis

The supplied TKA planning specification describes a preoperative planning suite before VR simulation. It covers FLAP and KLAT views, target alignment, component sizing/position, resection plane depth/angle, and transferring a locked plan into VR.

## Planning views

### FLAP
The supplied Articulus material identifies HKA, mPTA, mLDFA and VCA under FLAP.

### KLAT
The supplied material identifies approximate tibial and femoral component sizing under KLAT.

## Planning parameters recorded by the supplied specification

### MAD
Overall mechanical-axis/deformity information used to project a target weight-bearing vector in VR.

### AMA / VCA
Anatomic-to-mechanical/femoral correction angle information associated with distal femoral resection guide positioning relative to the intramedullary rod trajectory.

### mHKA / HKA
Baseline coronal deformity and target-threshold information for post-operative correction.

### MPTA / mPTA
Tibial proximal cut orientation relative to the mechanical axis.

### LDFA / mLDFA
Distal femoral deformity contribution.

### Posterior tibial slope
Backward tilt angle of the tibial cutting jig in VR.

### Resection thickness
Femoral/tibial resection thickness used to position saw guides relative to bone landmarks.

### AP/ML bone dimensions
Dimensions used to support component sizing and help prevent overhang or undersizing.

## Suggested data representation

```text
measurement
- parameter
- plane
- source_view
- planned_value
- actual_value
- deviation
- unit
- metadata
```

## Preoperative flow

```text
Assessment Page
-> Femoral Planning
-> Tibial Planning
-> Review & OR Transfer
-> lock plan
-> export plan
-> VR consumes locked plan
```

## Clinical safety boundary

This document records source-supported workflow concepts. It does not authorize new clinical thresholds, implant recommendations, or surgical decisions.

Any tolerance, correction target, sizing algorithm, or automated clinical rule not explicitly supplied must be clinically reviewed before production.
