# Reporting and Analytics

## Report types

### Resident
- competency
- progression
- completion
- case history
- attempt history
- skill performance
- recurring errors
- recommendations
- instructor feedback

### Cohort
- size
- completion
- competency distribution
- skill distribution
- at-risk learners
- case performance
- assessment activity

### Case
- attempts
- pass/fail
- average score
- common errors
- skill impact
- trend

### Skill
- population score
- resident distribution
- weak areas
- progress trend

## Derived metrics

Possible metrics:
- completion rate
- assessment completion rate
- average attempts per case
- repeat-error rate
- skill improvement delta
- time-to-completion
- case pass rate

Every metric must define source tables, inclusion rules, time window, denominator, and missing-data handling.

## Competency history

Never overwrite history when a new assessment is completed. Store the observation and calculate the current view from historical observations.

## Performance strategy

Start with SQL queries and indexes. Add caching/materialized views or separate analytics infrastructure only when justified by observed workload.

## Export

Exports should run server-side, honor authorization, record the requesting user, include generated-at time, and identify the reporting period.
