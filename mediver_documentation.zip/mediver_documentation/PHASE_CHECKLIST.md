# Phase Checklist

| Phase | Deliverable | Tests | Demo gate |
|---|---|---|---|
| 0 | Documentation + assumptions | Doc review | Team agrees scope |
| 1 | Engineering skeleton | CI/lint/typecheck | App + API start |
| 2 | PostgreSQL schema | Migration/seed | Clean DB rebuild |
| 3 | Auth/RBAC | Permission tests | Role-isolated login |
| 4 | Program management | CRUD tests | Instructor configures program |
| 5 | Cohorts/residents | Integration tests | Assignment works |
| 6 | Sessions | State tests | Session lifecycle works |
| 7 | VR contract | Contract tests | Simulated VR attempt |
| 8 | Assessment | Golden tests | Deterministic score |
| 9 | Review | E2E | Instructor reviews attempt |
| 10 | Live monitoring | WS tests | Live session |
| 11 | Reports | Query tests | Export/report |
| 12 | TKA planning | Data/contract tests | Locked plan enters VR |
| 13 | Hardening | Security/recovery/regression | Release candidate |
| 14 | Pilot | Acceptance validation | Controlled pilot |
