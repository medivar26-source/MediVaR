# Security, Audit and Clinical-Safety Controls

## Authentication

Implement secure password storage, session/token handling, logout/revocation, password reset if needed, and account status checks.

## Authorization

Initial roles:
- Instructor
- Resident
- Admin/Institution if required

Examples:
- resident cannot edit assessment criteria
- resident cannot access another resident's private record
- instructor cannot cross institution boundary
- only permitted roles can delete configuration

## Tenant isolation

Enforce institution scope on the backend. Never rely only on frontend visibility.

## Audit

Audit user/role changes, assessment configuration changes, case/procedure changes, skill weight changes, deletion/archive actions, finalized assessments, and report exports.

## Immutable assessment history

After finalization:
- raw events remain preserved
- configuration versions remain referenced
- finalized results are not silently overwritten

Corrections should create an explicit audit trail.

## Data minimization

Do not introduce real patient identifiers unless required and formally approved.

## Secrets

Never commit passwords, API keys, production tokens, certificates or private keys.

## Clinical safety

Mediver is a training/assessment platform. It should not silently behave as an autonomous clinical decision-maker.

Every clinical rule should have a named owner, version, source/rationale, and approval status.

## Failure cases

Design detectable recovery paths for:
- failed assessment calculation
- lost VR connection
- duplicate events
- database failure
- unauthorized access
- corrupt content/configuration
