# Antigravity Phase Prompts

## Master instruction

```text
You are the implementation agent for Mediver.

Before changing code:
1. Read every file under /docs.
2. Treat /docs as the current product/architecture contract.
3. Do not invent clinical rules, thresholds, score formulas, or medical recommendations that the documentation does not define.
4. When something is unspecified, create a clearly marked configuration placeholder or implementation TODO.
5. Inspect the existing repository before creating files.
6. Reuse existing code where appropriate.
7. Do not rewrite unrelated modules.
8. Implement only the requested phase.
9. Add/update tests for the phase.
10. Run lint, type checks and relevant tests.
11. Summarize changed files, tests, assumptions and blockers.
12. Stop after the current phase. Do not begin later phases automatically.
```

## Phase 1

```text
Execute Phase 1 from /docs/15_ANTIGRAVITY_BUILD_PLAN.md.
Build only the engineering foundation: frontend skeleton, backend skeleton, database connection layer, environment configuration, health/readiness endpoints, logging, structured API errors, test runner, lint/typecheck, and local development setup.
Do not implement product features yet.
Run all available checks and report exact commands/results.
```

## Phase 2

```text
Execute Phase 2.
Implement the PostgreSQL schema exactly from /docs/06_DATABASE_SCHEMA.md.
Create migrations, constraints, indexes and deterministic seed data.
Do not invent new clinical fields unless justified and documented.
Verify clean migration, seed reproducibility and foreign-key integrity.
Stop when Phase 2 is complete.
```

## Phase 3

```text
Execute Phase 3.
Implement authentication, RBAC and institution-level isolation.
Test valid/invalid login, protected endpoints, instructor access, resident access, cross-institution denial and unauthorized-role denial.
Do not proceed to Phase 4.
```

## Phase 4

```text
Execute Phase 4.
Build instructor program management: dashboard shell, curriculum, cases, procedures, skills, assessment settings and content/case library.
Use /docs/04_UI_AND_NAVIGATION.md.
Every screen needs loading, empty, error and unauthorized states.
Do not implement VR or live monitoring yet.
```

## Phase 5

```text
Execute Phase 5.
Build cohorts, cohort members, residents, resident profile and training assignments.
Connect to persisted backend data. Do not fake data once APIs exist.
Stop after tests pass.
```

## Phase 6

```text
Execute Phase 6.
Build upcoming/live/completed sessions, session details, participants, start/end controls and a validated session state machine.
Add integration tests.
```

## Phase 7

```text
Execute Phase 7.
Implement attempt and VR contracts from /docs/07_API_CONTRACTS.md and /docs/10_VR_INTEGRATION.md.
Support attempt creation, ordered-event ingestion, measurements, idempotent retries, sequence validation and completion.
Create a simulated VR test fixture.
Do not calculate final scores in the simulated client.
```

## Phase 8

```text
Execute Phase 8.
Implement the assessment engine from /docs/08_ASSESSMENT_ENGINE.md.
Build criterion evaluation, deviation handling, severity, skill aggregation, overall scoring pipeline, automatic-failure rules, explanation payloads and recommendations.
Use configuration for thresholds.
Do not invent missing clinical thresholds or competency formulas.
Create golden tests.
```

## Phase 9

```text
Execute Phase 9.
Build instructor review: attempt detail, score, skill breakdown, plan vs execution, errors, feedback, notes and recommendations.
Every displayed result must be traceable to persisted evidence.
```

## Phase 10

```text
Execute Phase 10.
Implement real-time session monitoring using the selected WebSocket mechanism.
Support join, start, current step, progress/status, completion and reconnect.
Add multi-client tests.
```

## Phase 11

```text
Execute Phase 11.
Implement resident, cohort, case and skill reports plus export/share.
For every metric document source, calculation, filters, time window and null handling.
Do not add a warehouse unless measured workload requires it.
```

## Phase 12

```text
Execute Phase 12.
Implement the supplied TKA preoperative planning workflow: FLAP/KLAT data, assessment page, femoral planning, tibial planning, review/lock, versioned plan and VR transfer contract.
Read /docs/09_TKA_PLANNING_AND_CLINICAL_DATA.md first.
Do not invent clinical targets or tolerances. Missing medical rules become configurable placeholders with approval status.
```

## Phase 13

```text
Execute Phase 13.
Harden the complete system with audit logs, authorization tests, backup/recovery verification, error tracking, performance checks, accessibility checks, security checks and regression testing.
Do not start pilot deployment.
```

## Phase 14

```text
Execute Phase 14.
Prepare a controlled pilot. Validate content, instructor workflow, resident VR workflow, assessment outputs, reporting and recovery procedures.
Generate a pilot-readiness report with PASS/FAIL for each gate.
Do not claim clinical readiness unless clinical approval gates have actually passed.
```
