# Open Decisions

These items must be resolved before clinical production.

## 1. Final competency formula
The current examples do not establish a single formula that reproduces every displayed overall competency.

## 2. Criterion scoring
Define exactly how a measurement maps to criterion points.

Needed:
- target
- tolerance
- warning range
- severity
- point curve or pass/fail logic

## 3. Clinical tolerances
For each clinically meaningful parameter define acceptable, warning, major and critical ranges. Clinical approval is required.

## 4. Parameter conventions
Confirm units, sign conventions, planes, left/right conventions, coordinate system and rounding rules.

## 5. Procedure event vocabulary
Finalize stable event types from the actual VR implementation.

## 6. Case versioning
Confirm whether editing creates a new version. Historical attempts must remain tied to the version used.

## 7. Plan locking
Confirm when a preoperative plan becomes immutable.

## 8. Guidance policy
Define guidance for training, assessment, preview and any other modes.

## 9. Resident result visibility
Decide what assessment information a resident immediately sees.

## 10. Recommendation policy
Decide whether recommendations are advisory, instructor-approved, editable, automatic, or some combination.

## 11. VR artifact storage
Decide whether replay/video/3D artifacts are stored in object storage, on-device, or not stored.

## 12. Deployment constraints
Decide cloud/on-prem, institution network constraints, VR hardware, supported browsers, and offline behavior.

## 13. Clinical governance
Name product owner, clinical owner, assessment owner and release approver.
