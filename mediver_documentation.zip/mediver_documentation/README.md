# Mediver Documentation Pack

Mediver is a medical VR training and assessment platform for Total Knee Arthroplasty (TKA) residency training.

This documentation pack is intended to be the source-of-truth package for implementation with Antigravity.

## Documentation map

| File | Purpose |
|---|---|
| 01_PRODUCT_VISION.md | Product purpose, users, scope, MVP boundary |
| 02_REQUIREMENTS.md | Functional and non-functional requirements |
| 03_USER_JOURNEYS.md | End-to-end instructor and resident journeys |
| 04_UI_AND_NAVIGATION.md | Instructor information architecture and screen behavior |
| 05_SYSTEM_ARCHITECTURE.md | Frontend, backend, DB, assessment, VR and real-time architecture |
| 06_DATABASE_SCHEMA.md | Relational schema, relationships, constraints and indexing |
| 07_API_CONTRACTS.md | API/resource design and VR/backend contract |
| 08_ASSESSMENT_ENGINE.md | Assessment lifecycle, scoring architecture, errors and recommendations |
| 09_TKA_PLANNING_AND_CLINICAL_DATA.md | Planning data and parameters supported by the supplied TKA planning specification |
| 10_VR_INTEGRATION.md | VR event model, attempt lifecycle, synchronization and failure handling |
| 11_REPORTING_ANALYTICS.md | Resident, cohort, case and skill analytics |
| 12_SECURITY_AUDIT_AND_COMPLIANCE.md | Authentication, authorization, audit and safety-oriented controls |
| 13_TESTING_STRATEGY.md | Unit, integration, E2E, VR integration and clinical validation strategy |
| 14_DEPLOYMENT_AND_OPERATIONS.md | Environments, migrations, observability, backups and rollout |
| 15_ANTIGRAVITY_BUILD_PLAN.md | Master phased implementation plan for Antigravity |
| 16_ANTIGRAVITY_PHASE_PROMPTS.md | Copy/paste prompts for each implementation phase |
| 17_SEED_DATA_AND_DEMO.md | Demo data and deterministic scenarios |
| 18_OPEN_DECISIONS.md | Questions that must be decided before clinical production |
| 19_DEFINITION_OF_DONE.md | Completion gates for the product |
| PHASE_CHECKLIST.md | One-page implementation checklist |

## Important source boundary

The supplied materials establish the TKA planning workflow, instructor application structure, and example data. The implementation should preserve those concepts.

Clinical values, tolerances, score formulas, and safety rules that are not explicitly defined in the source material must remain configurable or be marked as pending clinical approval. The application must not invent medical rules.

## Recommended implementation order

1. Read all documentation.
2. Create architecture and repository skeleton.
3. Create database and migrations.
4. Implement authentication and authorization.
5. Implement the instructor application.
6. Implement case/procedure configuration.
7. Implement resident/VR contracts.
8. Implement assessment engine.
9. Implement live sessions.
10. Implement analytics/reports.
11. Harden, validate and pilot.

Antigravity should implement one phase at a time, run the phase gates, and stop before starting the next phase.
