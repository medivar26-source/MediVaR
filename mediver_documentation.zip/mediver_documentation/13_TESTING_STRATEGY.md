# Testing Strategy

## Test levels

```text
E2E
 |
Integration + VR Contract
 |
Unit
```

## Unit tests

Test criterion evaluation, deviation calculations, severity classification, score aggregation, automatic failure, recommendations, permissions, and state transitions.

## Integration tests

Test API + DB, transaction behavior, event ingestion, assessment persistence, institution isolation, and session lifecycle.

## Contract tests

Test that VR and backend agree on event shape, IDs, sequence behavior, units, optional/required fields, acknowledgments, and version fields.

## E2E minimum

1. Instructor login
2. Create/select cohort
3. Assign case
4. Create session
5. Resident starts attempt
6. Events arrive
7. Attempt completes
8. Assessment generated
9. Instructor reviews
10. Feedback saved
11. Recommendation appears

## Assessment golden tests

Fixtures should include:
- perfect execution
- warning deviation
- major deviation
- critical error
- incomplete procedure
- duplicate event
- out-of-order event
- missing measurement
- reconnect
- no data

## Clinical validation

Clinical SMEs should validate terminology, planning workflow, parameter definitions, tolerances, severity mapping, scoring and recommendations.

Software tests cannot substitute for clinical approval.

## Regression

Every phase runs lint, type checks, unit tests and relevant integration tests. Keep the main branch green.
