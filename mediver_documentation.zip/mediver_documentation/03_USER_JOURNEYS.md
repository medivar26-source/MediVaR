# User Journeys

## Instructor journey

```text
Login
-> Dashboard
-> Select Cohort
-> Inspect residents
-> Identify at-risk resident
-> Review resident profile
-> Inspect case history
-> Open attempt
-> Review plan vs execution
-> Inspect errors
-> Add feedback
-> Assign targeted training
-> Monitor next session
-> Review progression
```

## Program authoring journey

```text
Program
-> Curriculum
-> Cases
-> Procedures
-> Skills
-> Assessment rules
-> Cohort
-> Residents
-> Assignment
-> Session
```

## Resident journey

```text
Login
-> Assigned training
-> Select case
-> Case briefing
-> Select/enter mode
-> Start attempt
-> Follow procedure
-> Emit VR events
-> Complete
-> Submit
-> Assessment generated
-> Result shown according to policy
-> Progress updated
```

## Assessment journey

```text
Start attempt
-> capture raw events
-> normalize measurements
-> evaluate criteria
-> classify errors
-> calculate criterion results
-> calculate skill results
-> apply automatic-failure rules
-> calculate final score/result
-> persist immutable assessment snapshot
-> generate recommendation
-> update derived competency
```

## Review journey

```text
Dashboard alert
-> Resident
-> Case attempt
-> Error
-> Parameter deviation
-> Relevant step/event
-> Instructor feedback
```
