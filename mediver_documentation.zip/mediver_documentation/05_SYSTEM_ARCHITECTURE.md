# System Architecture

## Logical architecture

```text
                 Instructor Web App
                        |
                      HTTPS
                        v
                   Backend API
             /       |       |       \
          Auth   Training  Session  Assessment
            |        |        |         |
            +--------+--------+---------+
                        |
                    PostgreSQL
                        ^
                        |
                 VR HTTPS / WS
                        |
                  Resident VR App
```

## Backend boundaries

### Auth
Identity, role, institution scope, sessions/tokens.

### Training
Programs, cohorts, assignments, cases, procedures, skills.

### Sessions
Scheduled/live/completed sessions, participants and live state.

### Attempts
Attempt lifecycle, event ingestion, measurements.

### Assessment
Criteria, error classification, score calculation, result persistence, recommendations.

### Reporting
Read/query layer for resident, cohort, case and skill reporting.

## Source of truth

### Source-of-truth
- configuration
- raw VR event stream
- measurements
- finalized assessment results
- instructor feedback

### Derived
- dashboard KPIs
- trends
- risk flags
- competency summaries
- report aggregates

Derived values may be cached later but must be reproducible from source data.

## Versioning

Clinical content that can affect assessment should be versioned:
- procedure version
- case version
- assessment configuration version
- assessment criteria version

A completed attempt references the versions used at execution time.

## Multi-tenancy

Institution scope must be enforced on backend queries. Client-provided IDs must never bypass tenant authorization.

## Technology direction

Recommended starting point:
- React/Next.js frontend
- FastAPI or equivalent backend
- PostgreSQL
- WebSocket for live monitoring
- Unity or selected VR stack

Keep the stack replaceable behind clear contracts.
